'use strict';

var walletDecryptDrtv = function() {
	return {
        restrict : "E",
        template : require('./walletDecryptDrtv.html')
  };
};
module.exports = walletDecryptDrtv;
